# PADI-2015

"The PADI project aims at implementing a simplified (and therefore, not complete), inmemory
implementation of the Map Reduce programming model."